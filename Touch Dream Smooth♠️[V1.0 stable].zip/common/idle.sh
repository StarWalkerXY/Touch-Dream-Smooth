function boot_wait() {
 while [[ -z $(getprop sys.boot_completed) ]]; do sleep 5; done
}

function global_table_set() {
  settings put global $1 $2
}

function global_table_unset() {
  settings delete global $1
}

boot_wait

if [[ ! -f /data/adb/modules/idle/disable ]]; then
  global_table_set device_idle_constants light_after_inactive_to=0,light_pre_idle_to=5000,light_idle_to=3600000,light_max_idle_to=43200000,locating_to=5000,location_accuracy=1000,inactive_to=0,sensing_to=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_to=21600000,max_idle_to=172800000,quick_doze_delay_to=5000,min_time_to_alarm=300000
else
  global_table_unset device_idle_constants
fi

if [[ ! -d /data/adb/modules/idle ]]; then
  global_table_unset device_idle_constants
  rm /data/adb/service.d/idle.sh
fi