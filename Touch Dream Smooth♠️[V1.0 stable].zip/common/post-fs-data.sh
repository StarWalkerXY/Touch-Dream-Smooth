#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}
if [[ -f /data/adb/modules/idle/idle.sh ]]; then
mv /data/adb/modules/idle/idle.sh /data/adb/service.d
chmod +x /data/adb/service.d/idle.sh
while [[ -z $(resetprop sys.boot_completed) ]]; do sleep 5; done
su -lp 2000 -c
busybox=/data/adb/magisk/busybox
done
echo "3" > /proc/sys/vm/drop_caches
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom
echo "0 0 0 0" > /proc/sys/kernel/printk 
echo off > /proc/sys/kernel/printk_devkmsg
cmd package bg-dexopt-job
fi